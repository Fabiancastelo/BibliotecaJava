import java.util.ArrayList;
import java.util.List;

import classes.Funcionario;
import classes.Livro;
import classes.Menu;
import classes.Usuario;

public class SistemaBiblioteca {

	public static void main(String[] args) {
		 List<Livro> livros = new ArrayList<>();
	        List<Usuario> usuarios = new ArrayList<>();
	        List<Funcionario> funcionarios = new ArrayList<>();

	        // Dados iniciais
	        livros.add(new Livro("Dom Quixote", "Miguel de Cervantes", "123456", 1605));
	        livros.add(new Livro("1984", "George Orwell", "789012", 1949));
	        usuarios.add(new Usuario("Ana"));
	        funcionarios.add(new Funcionario("Carlos", "carlos", "1234"));

	        // Criação do Menu
	        Menu menu = new Menu(livros, usuarios, funcionarios);
	        menu.exibirMenu();
	}

}
