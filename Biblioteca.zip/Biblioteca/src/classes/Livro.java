package classes;

public class Livro {
	private String titulo;
	private String autor;
	private String isbn;
	private int anoPublicacao;
	private boolean disponivel;

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public String getISBN() {
		return isbn;
	}

	public void setISBN(String isbn) {
		this.isbn = isbn;
	}

	public int getAnoPublicacao() {
		return anoPublicacao;
	}

	public void setAnoPublicacao(int anoPublicacao) {
		this.anoPublicacao = anoPublicacao;
	}

	public boolean isDisponivel() {
		return disponivel;
	}

	public void setDisponivel(boolean disponivel) {
		this.disponivel = disponivel;
	}

	public Livro(String titulo, String autor, String isbn, int anoPublicacao) {
		this.titulo = titulo;
		this.autor = autor;
		this.isbn = isbn;
		this.anoPublicacao = anoPublicacao;
		this.disponivel = false;
	}

	public Livro() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "\"" + titulo + "\" - " + autor + " (" + anoPublicacao + ") - ISBN: " + isbn + " - " + (disponivel ? "Emprestado" : "Disponível");
	}
}
