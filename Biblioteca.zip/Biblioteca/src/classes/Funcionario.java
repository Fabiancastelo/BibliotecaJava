package classes;
import interfaces.Cadastro;

public class Funcionario implements Cadastro {
	private static int contador = 1;
	private int id;
	private String nomeFuncionario;
	private String login;
	private String senha;
	
	public Funcionario(String nomeFuncionario, String login, String senha) {
		this.id = contador++;
		this.nomeFuncionario = nomeFuncionario;
		this.login = login;
		this.senha = senha;
	}
	
	public boolean autenticar (String login, String senha) {
		return this.login.equals(login) && this.senha.equals(senha);
	}
	
	public void registrarEmprestimo(Usuario usuario, Livro livro) {
		usuario.emprestarLivro(livro);
	}
	
	public void registrarDevolucao(Usuario usuario, Livro livro) {
		usuario.devolverLivro(livro);
	}
	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getNomeFuncionario() {
		return nomeFuncionario;
	}

	public void setNomeFuncionario(String nomeFuncionario) {
		this.nomeFuncionario = nomeFuncionario;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}
	
	public void cadastrar() {
		
	}
	
	public String toString() {
		return "Funcionário: " + nomeFuncionario + " | ID: " + id;
	}
	
}
