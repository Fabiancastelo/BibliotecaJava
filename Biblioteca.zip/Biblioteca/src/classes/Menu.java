package classes;

import java.util.List;
import java.util.Scanner;

public class Menu {
	private Scanner leitor;
	private List<Livro> livros;
	private List<Usuario> usuarios;
	private List<Funcionario> funcionarios;
	private Funcionario funcionarioLogado;

	public Menu(List<Livro> livros, List<Usuario> usuarios, List<Funcionario> funcionarios) {
		this.leitor = new Scanner(System.in);
		this.livros = livros;
		this.usuarios = usuarios;
		this.funcionarios = funcionarios;
		this.funcionarioLogado = null;
	}

	public void exibirMenu() {
	    int opcao;
	    do {
	        System.out.println("\n=== MENU BIBLIOTECA ===");
	        
	        if (funcionarioLogado == null) {
	            // Menu antes do login
	            System.out.println("1 - Login de funcionário");
	            System.out.println("2 - Listar livros disponíveis para empréstimo");
	            System.out.println("0 - Sair");
	        } else {
	            // Menu completo após login
	            System.out.println("1 - Cadastrar livro");
	            System.out.println("2 - Cadastrar usuário");
	            System.out.println("3 - Cadastrar funcionário");
	            System.out.println("4 - Logout do funcionário");
	            System.out.println("5 - Registrar empréstimo");
	            System.out.println("6 - Registrar devolução");
	            System.out.println("7 - Listar livros disponíveis para empréstimo");
	            System.out.println("0 - Sair");
	        }

	        System.out.print("Escolha uma opção: ");
	        opcao = leitor.nextInt();
	        leitor.nextLine(); // limpar buffer

	        if (funcionarioLogado == null) {
	            switch (opcao) {
	                case 1:
	                    loginFuncionario();
	                    break;
	                case 2:
	                    listarLivrosDisponiveis();
	                    break;
	                case 0:
	                    System.out.println("Sistema encerrado.");
	                    break;
	                default:
	                    System.out.println("Opção inválida.");
	            }
	        } else {
	            switch (opcao) {
	                case 1:
	                    cadastrarLivro();
	                    break;
	                case 2:
	                    cadastrarUsuario();
	                    break;
	                case 3:
	                    cadastrarFuncionario();
	                    break;
	                case 4:
	                    funcionarioLogado = null;
	                    System.out.println("Logout realizado.");
	                    break;
	                case 5:
	                    registrarEmprestimo();
	                    break;
	                case 6:
	                    registrarDevolucao();
	                    break;
	                case 7:
	                    listarLivrosDisponiveis();
	                    break;
	                case 0:
	                    System.out.println("Sistema encerrado.");
	                    break;
	                default:
	                    System.out.println("Opção inválida.");
	            }
	        }

	    } while (opcao != 0);
	}

	private void cadastrarLivro() {
		if (funcionarioLogado == null) {
			System.out.println("Você precisa estar logado como funcionário para cadastrar novos livros.");
			return;
		}

		System.out.print("Título: ");
		String titulo = leitor.nextLine();
		System.out.print("Autor: ");
		String autor = leitor.nextLine();
		System.out.print("ISBN: ");
		String isbn = leitor.nextLine();
		System.out.print("Ano: ");
		int ano = leitor.nextInt();
		leitor.nextLine(); // Limpar buffer

		livros.add(new Livro(titulo, autor, isbn, ano));
		System.out.println("Livro cadastrado.");

	}

	private void cadastrarUsuario() {
		if (funcionarioLogado == null) {
			System.out.println("Você precisa estar logado como funcionário para cadastrar novos usuários.");
			return;
		}

		System.out.print("Nome do usuário: ");
		String nomeUsuario = leitor.nextLine();
		Usuario novoUsuario = new Usuario(nomeUsuario);
		usuarios.add(novoUsuario);
		System.out.println("Usuário cadastrado com ID: " + novoUsuario.getId());
	}

	private void cadastrarFuncionario() {
		System.out.print("Nome do funcionário: ");
		String nomeFunc = leitor.nextLine();
		System.out.print("Login: ");
		String login = leitor.nextLine();
		System.out.print("Senha: ");
		String senha = leitor.nextLine();
		funcionarios.add(new Funcionario(nomeFunc, login, senha));
		System.out.println("Funcionário cadastrado.");
	}

	private void loginFuncionario() {
		System.out.print("Login: ");
		String loginInput = leitor.nextLine();
		System.out.print("Senha: ");
		String senhaInput = leitor.nextLine();

		funcionarioLogado = null;
		for (Funcionario f : funcionarios) {
			if (f.autenticar(loginInput, senhaInput)) {
				funcionarioLogado = f;
				break;
			}
		}

		if (funcionarioLogado != null) {
			System.out.println("Login bem-sucedido. Funcionário: " + funcionarioLogado);
		} else {
			System.out.println("Login inválido.");
		}
	}

	private void registrarEmprestimo() {
		if (funcionarioLogado == null) {
			System.out.println("Você precisa estar logado como funcionário para registrar empréstimos.");
			return;
		}

		System.out.print("ID do usuário: ");
		int idUsuario = leitor.nextInt();
		leitor.nextLine(); // Limpar buffer

		if (idUsuario <= 0 || idUsuario > usuarios.size()) {
			System.out.println("Usuário inválido.");
			return;
		}
		
		Usuario usuario = usuarios.get(idUsuario - 1);

		System.out.println("Livros disponíveis:");
		for (int i = 0; i < livros.size(); i++) {
			if (!livros.get(i).isDisponivel()) {
				System.out.println(i + " - " + livros.get(i));
			}
		}

		System.out.print("Digite o número do livro: ");
		int idLivro = leitor.nextInt();
		leitor.nextLine(); // Limpar buffer

		if (idLivro < 0 || idLivro >= livros.size()) {
			System.out.println("Livro inválido.");
			return;
		}

		funcionarioLogado.registrarEmprestimo(usuario, livros.get(idLivro));
		
		System.out.println("Livro emprestado para " + usuario.getNome() + ": " + livros.get(idLivro) );
	}

	private void registrarDevolucao() {
		if (funcionarioLogado == null) {
			System.out.println("Você precisa estar logado como funcionário para registrar devoluções.");
			return;
		}

		System.out.print("ID do usuário: ");
		int idU = leitor.nextInt();
		leitor.nextLine(); // Limpar buffer

		if (idU <= 0 || idU > usuarios.size()) {
			System.out.println("Usuário inválido.");
			return;
		}

		Usuario u = usuarios.get(idU - 1);

		System.out.println("Livros emprestados por " + u.getNome() +":");
		for (int i = 0; i < u.getLivrosEmprestados().size(); i++) {
			System.out.println(i + " - " + u.getLivrosEmprestados().get(i));
		}

		System.out.print("Digite o número do livro para devolver: ");
		int numLivro = leitor.nextInt();
		leitor.nextLine(); // Limpar buffer

		if (numLivro < 0 || numLivro >= u.getLivrosEmprestados().size()) {
			System.out.println("Livro inválido.");
			return;
		}

		funcionarioLogado.registrarDevolucao(u, u.getLivrosEmprestados().get(numLivro));
	}

	private void listarLivrosDisponiveis() {
		System.out.println("=== Livros Disponíveis para Empréstimo ===");
		boolean encontrouDisponivel = false;
		for (Livro livro : livros) {
			if (!livro.isDisponivel()) {
				System.out.println(livro);
				encontrouDisponivel = true;
			}
		}
		if (!encontrouDisponivel) {
			System.out.println("Nenhum livro disponível no momento.");
		}
	}
}
