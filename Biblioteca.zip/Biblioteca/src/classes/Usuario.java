package classes;
import java.util.ArrayList;
import java.util.List;

public class Usuario {
	private static int contador = 1;
	private int id;
	private String nome;
	private List<Livro> livrosEmprestados;

	
	public Usuario(String nome){
		this.id = contador++;
		this.nome = nome;
		this.livrosEmprestados = new ArrayList<>();
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public List<Livro> getLivrosEmprestados() {
		return livrosEmprestados;
	}
	
	public void setLivrosEmprestados(List<Livro> livrosEmprestados) {
		this.livrosEmprestados = livrosEmprestados;
	}
	
	public void emprestarLivro(Livro livro) {
		if (livrosEmprestados.size() < 3 && !livro.isDisponivel()) {
			livrosEmprestados.add(livro);
			livro.setDisponivel(true);
		}else {
			System.out.println("Não é possível emprestar o livro.");
		}
	}
	
	public void devolverLivro(Livro livro) {
		if(livrosEmprestados.contains(livro)) {
			livrosEmprestados.remove(livro);
			livro.setDisponivel(false);
		}else {
			System.out.println("O usuário " + toString() + " não possui esse livro emprestado.");
		}
	}

	public String toString() {
		return "ID: " + id + " | Nome: " + nome;
	}
}
