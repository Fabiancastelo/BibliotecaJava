package interfaces;

public interface Cadastro {
void cadastrar();
}
