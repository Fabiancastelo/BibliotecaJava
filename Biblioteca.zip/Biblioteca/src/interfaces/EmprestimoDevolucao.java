package interfaces;
import classes.Livro;
import classes.Usuario;

public interface EmprestimoDevolucao {
void registrarEmprestimo (Usuario usuario, Livro livro);
void registrarDevolucao (Usuario usuario, Livro livro);
}
